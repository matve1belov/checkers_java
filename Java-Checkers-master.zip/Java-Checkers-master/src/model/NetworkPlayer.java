package model;

public class NetworkPlayer extends Player {

	@Override
	public boolean isHuman() {
		return false;
	}

	@Override
	public void updateGame(Game game) {}

}
